# ManaBot

Mana bot is a personal project I've developed to use with my friends on Telegram and Discord.
The bot is designed to search a database on my computer of Magic the Gathering cards and
post them in our chats on command. In addition, it can convert .cod files (.xml files) and .mwDeck
files (functionally .txt) to .txt files whenever they're posted in our discord group. This is
useful since the program we use, Cockatrice, is easiest to load MtG decks into by pasting a txt 
file from the clipboard.
The bot is also used for displaying MtG cards with the !card cardname command on discord and the
inline-bot command @LF_Mana\_Bot cardname command on telegram in private/direct messages.
