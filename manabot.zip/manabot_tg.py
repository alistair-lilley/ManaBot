'''                                                  MANABOT FOR TELEGRAM                                            '''
'''
    Mana Bot main (telegram implementation)
'''
# Bot-oriented imports
import asyncio, os, logging
from dotenv import load_dotenv
from aiogram import Bot, Dispatcher, executor
from aiogram.types import InlineQuery

from datetime import datetime

from helpers import *
from cardmanager import CardMgr

# Load all environment variables
load_dotenv()
TOKEN = os.getenv('TGTOKEN')
path_to_cards = os.getenv('CARDPATH')
path_to_bot = os.getenv('BOTPATH')
path_to_images = os.getenv('IMAGEPATH')
me = os.getenv('KOKITG')

# Start logging and initialize bot and dispatcher objects
logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)


########################################################################################################################
########################################################################################################################
########################################################################################################################

# Load CardMgr object
# This will load image & name dicts, card list, exists set, searchable card list, and merge sort them
# It will also store found cards for searching/checking
CardManager = CardMgr(path_to_images,path_to_cards,path_to_bot,me,bot=bot)

########################################################################################################################
########################################################################################################################
########################################################################################################################

# Send startup message
async def startAlert():
    dt = datetime.now().strftime("%d-%m-%Y %H:%M")
    upmsg = f"Bot has started: {dt}"
    await bot.send_message(me,upmsg)

# Startup
async def on_startup(d: Dispatcher):
    asyncio.create_task(startAlert())

########################################################################################################################
########################################################################################################################
########################################################################################################################

# Inline handler
# This was one hell of a mess, so lets clean it up!
@dp.inline_handler()
async def on_inline(message: InlineQuery):
    simplified = simplifyString(message.query)
    if simplified == '':
        return
    cardpic, cardd = None, None # just in case

    try:
        cardpic = await CardManager.searchImage(simplified)
    except:
        await bot.send_message(me,"Whoa! Big error in card pic search\nNext is card data search")

    try:
        cardd = await CardManager.searchDescription(simplified)
    except:
        await bot.send_message(me,"Whoa! Big error in card data search")

    # Results array
    # Store cardpic and cardd if they are found; if they failed, ignore them
    res = []
    if cardpic != None:
        res.append(cardpic)
    if cardd != None:
        res.append(cardd)

    # Try sending the data, and if it cant just throw an error
    if len(res) > 0:
        await bot.answer_inline_query(message.id, results=res, cache_time=1)
    else:
        await bot.send_message(me, f"There was an issue with sending a response to this query: {message}.\n"
                                   f"EVERYTHING went wrong, bro. Everything.")



if __name__ == '__main__':
    executor.start_polling(dp, on_startup=on_startup, skip_updates=True)